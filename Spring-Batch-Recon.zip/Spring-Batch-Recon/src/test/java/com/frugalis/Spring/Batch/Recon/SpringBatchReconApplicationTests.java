package com.frugalis.Spring.Batch.Recon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBatchReconApplicationTests {

	@Test
	void contextLoads() {
	}

}
