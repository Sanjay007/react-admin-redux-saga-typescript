package com.frugalis.Spring.Batch.Recon.configdata;

import lombok.Data;

@Data
class Variance {
    private int value;
    private String operation;
    private String function;
    private String stmtcolumn;
    private String cbcolumn;
}
