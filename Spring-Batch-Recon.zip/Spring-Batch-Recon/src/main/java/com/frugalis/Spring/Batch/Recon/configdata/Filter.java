package com.frugalis.Spring.Batch.Recon.configdata;

import lombok.Data;

@Data
class Filter {
    private String stmtFilterExpression;
    private String cashFilterExpression;
}
