package com.frugalis.Spring.Batch.Recon.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Record {
    private int amount;
    private String source;
    private String tradeRef;
    private String recordId;
    private String matchId;
    private String matchStatus;
    private String tradeDate;
    private String valueDate;
    private String ccy;
    private String isin;

    @Override
    public String toString() {
        return "Record{" +
                "amount=" + amount +
                ", source='" + source + '\'' +
                ", tradeRef='" + tradeRef + '\'' +
                ", recordId='" + recordId + '\'' +
                ", matchId='" + matchId + '\'' +
                ", matchStatus='" + matchStatus + '\'' +
                ", tradeDate='" + tradeDate + '\'' +
                ", valueDate='" + valueDate + '\'' +
                ", ccy='" + ccy + '\'' +
                ", isin='" + isin + '\'' +
                '}';
    }
}
