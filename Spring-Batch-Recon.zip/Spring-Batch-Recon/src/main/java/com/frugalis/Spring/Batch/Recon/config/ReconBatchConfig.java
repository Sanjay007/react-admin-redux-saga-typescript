package com.frugalis.Spring.Batch.Recon.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.frugalis.Spring.Batch.Recon.model.Record;
import lombok.SneakyThrows;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.MultiResourceItemReader;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;


@Configuration
@EnableBatchProcessing
public class ReconBatchConfig {
    @Autowired
    private JobBuilderFactory jobBuilderFactory;

    @Autowired
    StepBuilderFactory stepBuilderFactory;

    @Bean
    Job reconJob() {
        return jobBuilderFactory.get("reconciliationJob").incrementer(new RunIdIncrementer()).start(step1A()).build();
    }

    @Value("classpath*:/recpass.json")
    private Resource recpassJson;
    @Value("classpath*:/data/account*.csv")
    private Resource[] inputfiles;

    @Bean
    public MultiResourceItemReader<Record> multiResourceItemReader() {
        MultiResourceItemReader<Record> reader = new MultiResourceItemReader<>();
        reader.setDelegate(customerItemReader());
        reader.setResources(inputfiles);
        return reader;
    }

    @Bean
    public FlatFileItemReader<Record> customerItemReader() {
        FlatFileItemReader<Record> reader = new FlatFileItemReader<>();
        reader.setLinesToSkip(1);

        DefaultLineMapper<Record> customerLineMapper = new DefaultLineMapper<>();
        DelimitedLineTokenizer tokenizer = new DelimitedLineTokenizer();
        tokenizer.setNames(new String[]{"trade_ref", "value_date", "amount", "trade_date", "ccy", "isin", "side", "cr_dr_flag"});

        customerLineMapper.setLineTokenizer(tokenizer);
        customerLineMapper.setFieldSetMapper(new RecordSetMapper());
        customerLineMapper.afterPropertiesSet();

        reader.setLineMapper(customerLineMapper);

        return reader;
    }

    @Bean
    public Step step1A() {
        return stepBuilderFactory.get("step1A")
                .<Record, Record>chunk(1)
                .reader(multiResourceItemReader())

                .allowStartIfComplete(true)
                .build();
    }


    @Bean
    public ItemWriter<Record> BreakrecordItemWriter() {
        return items -> {
            for (Record item : items) {
                System.out.println(item.toString());
            }
        };
    }


    @SneakyThrows
    @Bean
    public ItemProcessor<Record, Record> processRecon() {
        File resource = new ClassPathResource("recpass.json").getFile();
        try {
            String text = new String(Files.readAllBytes(resource.toPath()));
            ObjectMapper objectMapper = new ObjectMapper();
            ReconciliationConfig config = objectMapper.readValue(text, ReconciliationConfig.class);
            return new ReconItemProcessor(config);

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
