package com.frugalis.Spring.Batch.Recon.configdata;

import lombok.Data;

@Data
public class Grouping {
    private int id;
    private String stmtcolumn;
    private String cbcolumn;
    private String stexp;
    private String cbexp;
}
