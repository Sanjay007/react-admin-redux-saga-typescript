package com.frugalis.Spring.Batch.Recon.config;

import com.frugalis.Spring.Batch.Recon.model.Record;
import org.springframework.batch.item.ItemProcessor;

public class ReconItemProcessor implements ItemProcessor<Record, Record> {
    private ReconciliationConfig config;

    public ReconItemProcessor(ReconciliationConfig config) {
        this.config = config;
    }
    @Override
    public Record process(Record record) throws Exception {
        return null;
    }



}
