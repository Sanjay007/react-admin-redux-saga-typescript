package com.frugalis.Spring.Batch.Recon.config;

import com.frugalis.Spring.Batch.Recon.configdata.Grouping;
import com.frugalis.Spring.Batch.Recon.model.Record;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class DynamicRecordGrouping {

    // Method to dynamically group records based on grouping configuration
    public Map<String, List<Record>> groupRecords(List<Record> records, List<Grouping> groupingConfig) {
        return records.stream()
                .collect(Collectors.groupingBy(record -> createGroupKey(record, groupingConfig)));
    }

    // Method to create a group key dynamically using reflection
    private String createGroupKey(Record record, List<Grouping> groupingConfig) {
        StringBuilder groupKey = new StringBuilder();

        for (Grouping grouping : groupingConfig) {
            String columnName = grouping.getStmtcolumn(); // or use cbcolumn depending on the context

            try {
                // Use reflection to dynamically get the field value
                Field field = Record.class.getDeclaredField(columnName);
                field.setAccessible(true);
                Object value = field.get(record);

                if (value != null) {
                    groupKey.append(value.toString());
                }
                groupKey.append("-"); // delimiter for grouping key
            } catch (NoSuchFieldException | IllegalAccessException e) {
                e.printStackTrace();
            }
        }

        return groupKey.toString();
    }
}

