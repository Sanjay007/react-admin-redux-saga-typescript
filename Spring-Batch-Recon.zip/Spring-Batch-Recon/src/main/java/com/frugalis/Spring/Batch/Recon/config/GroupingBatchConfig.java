package com.frugalis.Spring.Batch.Recon.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.frugalis.Spring.Batch.Recon.config.groupingbatch.FlatFileGroupedRecordProcessor;
import com.frugalis.Spring.Batch.Recon.config.groupingbatch.FlatFileGroupingItemReader;
import com.frugalis.Spring.Batch.Recon.configdata.Grouping;
import com.frugalis.Spring.Batch.Recon.config.ReconciliationConfig;
import com.frugalis.Spring.Batch.Recon.config.RecordSetMapper;
import com.frugalis.Spring.Batch.Recon.configdata.Rule;
import com.frugalis.Spring.Batch.Recon.model.Record;
import lombok.SneakyThrows;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;
import java.util.Map;

@Configuration
@EnableBatchProcessing
public class GroupingBatchConfig {


    @Autowired
    private JobBuilderFactory jobBuilderFactory;

    @Autowired
    private StepBuilderFactory stepBuilderFactory;

    @Bean
    public Job flatFileReconciliationJob() {
        return jobBuilderFactory.get("flatFileReconciliationJob")
                .start(flatFileReconciliationStep())
                .build();
    }

    @Bean
    public Step flatFileReconciliationStep() {
        return stepBuilderFactory.get("flatFileReconciliationStep")
                .<Map<String, List<Record>>, Map<String,String>>chunk(1) // Process one group at a time
                .reader(flatFileGroupingItemReader())
                .processor(flatFileGroupedRecordProcessor())
                .writer(flatFileItemWriter()) // Customize this writer based on your requirements
                .build();
    }

    @SneakyThrows
    @Bean
    public ItemReader<Map<String, List<Record>>> flatFileGroupingItemReader() {
        FlatFileItemReader<Record> flatFileReader = flatFileItemReader();

        // Fetch grouping config from your source (e.g., from the JSON)
        List<Grouping> groupingConfig = fetchGroupingConfig();

        // Create a flat file reader and wrap it in the grouping reader
        return new FlatFileGroupingItemReader(flatFileReader, groupingConfig);
    }

    private List<Grouping> fetchGroupingConfig() throws IOException {
        File resource = new ClassPathResource("recpass.json").getFile();
        try {
            String text = new String(Files.readAllBytes(resource.toPath()));
            ObjectMapper objectMapper = new ObjectMapper();
            ReconciliationConfig config = objectMapper.readValue(text, ReconciliationConfig.class);
            Rule rul1= config.getRules().get(0);
            return rul1.getGrouping();

        }catch (Exception e){
e.printStackTrace();
        }
        return null;
    }

    @Bean
    public ItemProcessor<Map<String, List<Record>>, Map<String,String>> flatFileGroupedRecordProcessor() {
        return new FlatFileGroupedRecordProcessor();
    }

    @Bean
    public ItemWriter<Map<String,String>> flatFileItemWriter() {
        return results -> {
            // Write your results to the desired output

                System.out.println("Flat File Reconciliation Result: " + results);

        };
    }


    @Bean
    public FlatFileItemReader<Record> flatFileItemReader() {
        FlatFileItemReader<Record> reader = new FlatFileItemReader<>();
        reader.setResource(new ClassPathResource("account1.csv")); // File path
        reader.setLinesToSkip(1); // Skip header
        reader.setLineMapper(lineMapper());
        return reader;
    }

    @Bean
    public LineMapper<Record> lineMapper() {
        DefaultLineMapper<Record> lineMapper = new DefaultLineMapper<>();

        DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
        lineTokenizer.setDelimiter(",");
        lineTokenizer.setNames( "trade_ref", "value_date", "amount", "trade_date", "ccy", "isin", "side", "cr_dr_flag" ); // Define column names

//        BeanWrapperFieldSetMapper<Record> fieldSetMapper = new BeanWrapperFieldSetMapper<>();
//        fieldSetMapper.setTargetType(Record.class);

        lineMapper.setLineTokenizer(lineTokenizer);
//        lineMapper.setFieldSetMapper(fieldSetMapper);
        lineMapper.setFieldSetMapper(new RecordSetMapper());

        return lineMapper;
    }
}
