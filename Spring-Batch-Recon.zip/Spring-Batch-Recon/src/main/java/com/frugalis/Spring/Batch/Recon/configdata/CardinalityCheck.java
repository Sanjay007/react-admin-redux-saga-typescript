package com.frugalis.Spring.Batch.Recon.configdata;

import lombok.Data;

@Data
public class CardinalityCheck {
    private int value;
    private String operator;
}
