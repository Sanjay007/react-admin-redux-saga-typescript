package com.frugalis.Spring.Batch.Recon.config.groupingbatch;

import com.frugalis.Spring.Batch.Recon.configdata.Grouping;
import com.frugalis.Spring.Batch.Recon.model.Record;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.file.FlatFileItemReader;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class FlatFileGroupingItemReader implements ItemReader<Map<String, List<Record>>> {

    private final FlatFileItemReader<Record> delegate;
    private final List<Grouping> groupingConfig;
    private boolean read = false;

    public FlatFileGroupingItemReader(FlatFileItemReader<Record> delegate, List<Grouping> groupingConfig) {
        this.delegate = delegate;
        this.groupingConfig = groupingConfig;
    }

    @Override
    public Map<String, List<Record>> read() throws Exception {
        if (!read) {
            List<Record> allRecords = new ArrayList<>();
            Record record;
            // Read all records from the flat file
            while ((record = delegate.read()) != null) {
                allRecords.add(record);
            }
            // Group the records based on the dynamic grouping configuration
            Map<String, List<Record>> groupedRecords = groupRecords(allRecords, groupingConfig);
            read = true; // Mark as read after the first execution
            return groupedRecords;
        } else {
            return null; // End of reading
        }
    }

    private Map<String, List<Record>> groupRecords(List<Record> records, List<Grouping> groupingConfig) {
        return records.stream()
                .collect(Collectors.groupingBy(record -> createGroupKey(record, groupingConfig)));
    }

    private String createGroupKey(Record record, List<Grouping> groupingConfig) {
        StringBuilder groupKey = new StringBuilder();
        for (Grouping grouping : groupingConfig) {
            String columnName = grouping.getStmtcolumn(); // or cbcolumn depending on context
            try {
                Field field = Record.class.getDeclaredField(columnName);
                field.setAccessible(true);
                Object value = field.get(record);
                if (value != null) {
                    groupKey.append(value.toString());
                }
                groupKey.append("-"); // delimiter
            } catch (NoSuchFieldException | IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        return groupKey.toString();
    }
}

