package com.frugalis.Spring.Batch.Recon.configdata;

import lombok.Data;

@Data
class Cardinality {
    private CardinalityCheck stmtCardinality;
    private CardinalityCheck cashCardinality;
}
