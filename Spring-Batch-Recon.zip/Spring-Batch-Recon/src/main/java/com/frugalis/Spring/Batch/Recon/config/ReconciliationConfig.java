package com.frugalis.Spring.Batch.Recon.config;

import com.frugalis.Spring.Batch.Recon.configdata.Rule;
import lombok.Data;

import java.util.List;

@Data
public class ReconciliationConfig {
    private List<Rule> rules;
}

