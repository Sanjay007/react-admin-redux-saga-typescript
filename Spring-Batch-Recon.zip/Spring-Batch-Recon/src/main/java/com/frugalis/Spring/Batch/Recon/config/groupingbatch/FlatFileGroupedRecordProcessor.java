package com.frugalis.Spring.Batch.Recon.config.groupingbatch;

import com.frugalis.Spring.Batch.Recon.model.Record;
import org.springframework.batch.item.ItemProcessor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FlatFileGroupedRecordProcessor implements ItemProcessor<Map<String, List<Record>>, Map<String,String>> {

    @Override
    public Map<String,String> process(Map<String, List<Record>> groupedRecords) throws Exception {
        // Process the grouped records, e.g., apply reconciliation logic
        for (Map.Entry<String, List<Record>> entry : groupedRecords.entrySet()) {
            String groupKey = entry.getKey();
            List<Record> recordsInGroup = entry.getValue();

            // Apply reconciliation logic to each group
            System.out.println("Processing group: " + groupKey + ", Record count: " + recordsInGroup.size());
        }

        // Return the result of processing
        return new HashMap<String,String>();
    }
}
