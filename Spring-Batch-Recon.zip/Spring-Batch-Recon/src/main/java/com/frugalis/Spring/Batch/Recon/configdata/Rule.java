package com.frugalis.Spring.Batch.Recon.configdata;

import lombok.Data;

import java.util.List;

@Data
public class Rule {
    private String ruleName;
    private int ruleId;
    private int ruleOrder;
    private Cardinality cardinality;
    private Filter filter;
    private List<Grouping> grouping;
    private String conditionExpression;
    private Variance variance;
}
