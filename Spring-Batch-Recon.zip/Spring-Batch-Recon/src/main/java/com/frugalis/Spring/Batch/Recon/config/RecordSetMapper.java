package com.frugalis.Spring.Batch.Recon.config;


import com.frugalis.Spring.Batch.Recon.model.Record;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

public class RecordSetMapper implements FieldSetMapper<Record> {

    @Override
    public Record mapFieldSet(FieldSet fieldSet) throws BindException {
        Record record = new Record();
        record.setAmount(fieldSet.readInt("amount"));
        record.setTradeRef(fieldSet.readString("trade_ref"));
        record.setSource(fieldSet.readString("side"));
        record.setValueDate(fieldSet.readString("value_date"));
        record.setTradeDate(fieldSet.readString("trade_date"));
        record.setCcy(fieldSet.readString("ccy"));
        record.setIsin(fieldSet.readString("isin"));

//        record.setField3(fieldSet.readDouble("field3"));
        return record;
    }
}